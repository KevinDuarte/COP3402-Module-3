#ifndef LEXER_H
#define LEXER_H

#include <stdio.h>

int pmachinemain();

#endif
